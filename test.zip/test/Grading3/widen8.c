
void tests(int i, float f)
{
  4 == i;
  '5' != i;
  '6' > i;

  i >= f;
  f <= i;

  i && f;

  'c' != f;

  'a' && f;

  'a' || i || f;
}
