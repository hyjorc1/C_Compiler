
int a, b, A[20];

float x, y, z;

char truth;

float b;  /* Should generate an error */
