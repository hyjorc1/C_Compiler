
void func()
{
  (int) 'A';
  (int) 3;
  (int) 4.1;

  (char) 'A';
  (char) 3;
  (char) 4.1;

  (float) 'A';
  (float) 3;
  (float) 4.1;
}
