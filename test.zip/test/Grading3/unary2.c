
float a;
int b;
char c;

void foo()
{
  ~b;
  ~c;

  -a;
  -b;
  -c;

  !a;
  !b;
  !c;

  ~ ~ c;
  - - - b;
  ! ! ! ! ! a;
  ! - ~ ! - ~ ! - ~ b;
}

