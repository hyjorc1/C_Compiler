
struct pair {
  int x, y;
};

struct pair getOrigin(int something)
{
  struct pair P;
  return P;
}
