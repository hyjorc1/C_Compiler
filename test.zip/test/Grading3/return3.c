
void func1()
{
  return func1();
}

char func2()
{
  char c;
  return c;
}

int func3()
{
  int i;
  return i;
}

float func4()
{
  float f;
  return f;
}

int bad()
{
  return 4.5;
}
