
float distance(float x1, float y1, float x2, float y2)
{
  x1;
  y1;
  x2;
  y2;
}

float random(int seed, char x1)
{
  seed;
  x1;
}

void error(int a, int b, int a);

