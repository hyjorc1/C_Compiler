
void what()
{
  -what();
  !what();
  ~what();
}

