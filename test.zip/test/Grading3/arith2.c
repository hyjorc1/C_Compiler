
void tests(int a, float b, char c)
{
  int A;
  float B;
  char C;

  a + A;
  a - A;
  a * A;
  a / A;
  A + a;
  A - a;
  A * a;
  A / a;

  a % A;
  A % a;
  a & A;
  A & a;
  a | A;
  A | a;

  b + B;
  b - B;
  b * B;
  b / B;
  B + b;
  B - b;
  B * b;
  B / b;

  c + C;
  c - C;
  c * C;
  c / C;
  C + c;
  C - c;
  C * c;
  C / c;

  1+a+2;
  (a+2)*(a+1)+3;
}
