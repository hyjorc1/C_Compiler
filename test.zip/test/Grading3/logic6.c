
float foo[50];

void tests()
{
  float bar[30];

  foo == bar;
  foo != bar;
  foo >  bar;
  foo >= bar;
  foo <  bar;
  foo <= bar;
  foo && bar;
  foo || bar;
}
