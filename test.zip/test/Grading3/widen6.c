
int foo()
{
  return 'a';
}

float bar()
{
  return 3;
}

void test()
{
  foo() + bar();
}
