
const int A[50];

void test()
{
  A[3]++;
}
