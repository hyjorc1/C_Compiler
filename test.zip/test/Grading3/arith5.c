
void tests()
{
  int A[50];

  /* All bad */

  A + A;
  A - A;
  A * A;
  A / A;
  A % A;
  A & A;
  A | A;
}
