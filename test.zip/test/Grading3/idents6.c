
void func1()
{
  int a, b, c;
  float f, g, h;
}

void func2()
{
  int a[50];
  float f;
}

void func3()
{
  int f, b;
  f;
  b;
}

void func4()
{
  int a, bad, thing;
  int bad;    /* error */
}
