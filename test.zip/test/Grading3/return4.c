
char c;
int i;
float f;

void func1()
{
  return;
}

char func2()
{
  return c;
}

int func3()
{
  return i;
}

float func4()
{
  return f;
}

float bad()
{
  return "4.5";
}
