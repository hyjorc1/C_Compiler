
char message[1000];

void tests(float f)
{
  message;
  message[5];

  /* Bad */
  message[f];
}
