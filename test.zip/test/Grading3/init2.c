
void test()
{
  float pi = 3.141592653589793238462643383279820974944; /* approximately */

  int i, j=10, k;

  char c = 'w';

}

