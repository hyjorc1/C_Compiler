
void everything(int a)
{
  int b;
  char c[17];
  float d;
  int e, f[5], g;

  a;
  b;
  c;
  d;
  e;
  f;
  g;
}

float b, a, d;

int still_good(int a, int b, int c, int e, int f, int g)
{
  float h, i, j;
  char k;

  a;
  b;
  c;
  d;
  e;
  f;
  g;
  h;
  i;
  j;
  k;
}

int i, j;

void thing(int a)
{
  a;
  b;
  d;
  i;
  j;
}

