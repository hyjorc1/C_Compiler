
void tests(int a, float b, char c)
{
  int A;
  float B;
  char C;

  a == A;
  a != A;
  a > A;
  a >= A;
  A < a;
  A <= a;
  A && a;
  A || a;

  b == B;
  b != B;
  B >  b;
  B >= b;
  b <  B;
  b <= B;
  B && b;
  B || b;

  C == c;
  c != C;
  C >  c;
  c >= C;
  C <  c;
  c <= C;
  C && c;
  c || C;
}
