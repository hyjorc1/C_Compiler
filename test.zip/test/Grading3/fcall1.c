
void func1()
{
  int a;
}

int func2()
{
  char b;
}

float func3()
{
  int x;
}

void func4()
{
  func1();
  func2();
  func3();
  func4();
}
