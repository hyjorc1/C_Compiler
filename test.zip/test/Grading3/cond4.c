
void nope();

void tests()
{
  do {
  } while (1);

  if (nope()) {
  }
}
