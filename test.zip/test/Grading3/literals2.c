
void integers()
{
  0;
  5;
  100;
  1234567890;
  -6;   /* technically, - literal */
}
