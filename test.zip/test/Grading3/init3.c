
float f;

void test(int a)
{
  int b = a;

  float g = f;

  int c, d=b;
}
