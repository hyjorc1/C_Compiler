
void test(int a)
{
  a = 'c';
}
