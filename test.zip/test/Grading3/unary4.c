
void bad()
{
  int A[50];

  -A;
  ~A;
  !A;
}
