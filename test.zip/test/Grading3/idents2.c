
int A[50];

void dummy();

float B;

void another();

char C;

int dummy;    /* OK */

void test()
{
  A;
  B;
  C;
}
