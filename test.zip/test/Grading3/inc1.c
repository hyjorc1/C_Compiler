
int a;
float b;
char c;

void tests()
{
  a++;
  ++a;
  b++;
  ++b;
  c++;
  ++c;

  a--;
  --a;
  b--;
  --b;
  c--;
  --c;
}
