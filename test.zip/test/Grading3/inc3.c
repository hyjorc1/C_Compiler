
int A[50];

void tests()
{
  /* All bad */

  A++;
  ++A;
  A--;
  --A;
}

