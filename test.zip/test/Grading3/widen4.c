
void test(int a, float b, char c)
{
  a + b + c;

  c ? a : b;
  a ? b : c;
  b ? a : c;
}
