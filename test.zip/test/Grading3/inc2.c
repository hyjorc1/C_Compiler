


void tests()
{
  int a, b;

  a++ == ++b;
  ++a == b++;
  a-- == b--;
  --a == --b;
}
