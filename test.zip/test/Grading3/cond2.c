
void tests(int a)
{
  float X[50];

  if (a) {

    while (X) { // nope
    }
  }
}

