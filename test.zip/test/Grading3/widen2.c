
float f;

void test()
{
  f = 1;
  f = 'c';

  f += 4;
  f -= 'b';
}
