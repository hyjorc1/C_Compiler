
int thingy(int a, int b);

void garbage();

int thingy(int a, int b, int c);    /* Nope */

