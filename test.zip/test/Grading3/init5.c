
int B;

void test()
{
  char space = ' ';
}

int A = 3.5;
