
void test(const int i, int j)
{
  3;
  i;
  j;
  i+j;
  3+i;
  3>i;
}
