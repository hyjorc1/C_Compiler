
void func1()
{
  return;
}

char func2()
{
  return 'c';
}

int func3()
{
  return 3;
}

float func4()
{
  return 4.0;
}

char bad()
{
  return;
}
