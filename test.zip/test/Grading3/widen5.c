
void test()
{
  int A[50];
  A;
  A[3];
  A['c'];
}
