
int A[50];

void tests()
{
  A;
  A[0];
  A[A[1]];
  A[A[A[2]]];
}
