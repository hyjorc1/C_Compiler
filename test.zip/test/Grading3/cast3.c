
void func()
{
  int A[50];

  (char) A;
  (int) A;
  (float) A;
}
