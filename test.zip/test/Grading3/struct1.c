
struct basic {
  int x, y;
  char name[50];
  float depth;
};

int filler;

struct basic B;

