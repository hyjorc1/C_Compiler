
/* Missing structs */

struct pair {
  int x, y;
};


void test(
  struct pair P, 
  struct missing M
)
{
  P;
}
