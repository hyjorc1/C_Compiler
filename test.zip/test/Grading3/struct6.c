
void test()
{
  struct local {
    int x, y, z;
  };

  int first;

  struct local L1;

  int second;

  first;
  L1;
  second;
}
