
void tests()
{
  int i;

  for (i=10; i; i--) {
  }

  for ( ; ; ) {
    break;
  }
}
