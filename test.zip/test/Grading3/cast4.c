
void func();

void other()
{
  (char) func();
  (int) func();
  (float) func();
}
