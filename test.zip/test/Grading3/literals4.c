
void strings()
{
  "Hello, world!";
  "A";
  "45";
  "/* This again?"; // */
  "";
}
