
void myfunc()
{
  int a, b, C[50];
  float d;
  char message[1024];

  a;
  b;
  C;
  d;
  message;
}
