
void test()
{
  3 + 'a';
  4 - 0.5;
  5.0 * 'b';
}
