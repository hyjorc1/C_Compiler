
float X[50];

void tests(int a)
{
  X;
  X[0];
  X[a];
  X[a+1];
  X[2*a+7];
  X[(2*a+7) % 5];
}
