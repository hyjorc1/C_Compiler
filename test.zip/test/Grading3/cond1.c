
void tests(int a, float b, char c)
{
  if (a) {
  }
  if (b) {
  } else {
  }

  while (c) {
  }
}

