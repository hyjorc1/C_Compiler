
float other_function(float x);

int myproto(int a, int b);

float other_function(float y);

int myproto(int c, int d)
{
  c;
  d;
}

int other_function(float z) /* error */
{
}

