
int A;

void tests(int i)
{
  A;
  /* All bad below here */
  A[0];
  A[i];
}
