
float a;
int b;
char c;

void func()
{
  (char) a;
  (char) b;
  (char) c;

  (int) a;
  (int) b;
  (int) c;

  (float) a;
  (float) b;
  (float) c;
}

