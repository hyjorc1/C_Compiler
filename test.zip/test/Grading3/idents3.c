
void myfunc(int a, float b, char c)
{
}

int a;  /* OK */

int foo(int b)    /* Also OK */
{
}
