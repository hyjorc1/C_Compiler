
int A[50];

void test(int a, int b)
{
  /* Bad condition */
  A ? a : b;
}
