
void fun()
{
  fun();
  putc('A');    /* error */
}
