
void characters()
{
  'a';
  'B';
  '3';
  ' ';
  '\t';
}
