
void print(int x);

void print(float x)   /* error */
{
  x;  
}

