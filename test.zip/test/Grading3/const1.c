
const float pi;

void test()
{
  pi = 3.14159;
}
