
float A=0.0, B=A, C=A;

void test()
{
  int x=0,
      y=x,
      z=A;    /* nope */
}
