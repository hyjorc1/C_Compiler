
int a;
float b;
char c;

void tests()
{
  a = 1;
  b = 1.0;
  c = '1';

  a += 1;
  b += 1.0;
  c += '1';

  a -= 1;
  b -= 1.0;
  c -= '1';

  a *= 2;
  b *= 2.0;
  c *= '2';

  a /= 2;
  b /= 2.0;
  c /= '2';
}
