
int bad_do_while()
{
  int x;
  do {
    x++;
  } while 1;  /* parens required */
}
