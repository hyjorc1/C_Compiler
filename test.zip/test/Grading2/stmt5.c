
void empty(int a)
{
  ;
  ;
  ;
  ;
  /* Empty expressions are legal in C */
}
