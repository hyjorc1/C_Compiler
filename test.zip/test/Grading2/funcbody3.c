
void print(int z);

void empty()
{
}

char error ( int a , int b )
;   /* <----- that's bad */
{
  int 
  x
  ;
}

