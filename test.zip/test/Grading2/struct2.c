
struct message {
  int x, y;
  char text[128];
};

int proto1(int a);

struct CSR_format {
  float X[1000];
  int col_index[1000];
  int row_pointer[100];
};


float random(float x)
{
  struct pair {
    float x;
    float y;
  };
  struct triple {
    float x;
    float y;
    float z;
  };
  float y;
  return x;
}

struct student {
  int ID;
  char first[50];
  char last[50];
};


int another_one(int z)
{
  struct tree {
    int left;
    int right;
    int parent;
    char label[12];
    int value;
  };
}
