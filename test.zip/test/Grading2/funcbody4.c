
int strange(int x)
{
  int y;

  int bad(int y);

  int z;

  /* Can't nest functions */
}

