
int bar(int A[])
{
  return A[5];
}

