
void bad()
{
  int x;

  while 
    ( /* nope */ )
  {
    x++;
  }
}
