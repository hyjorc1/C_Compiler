
struct thing 
{
  int random;
  float stuff[10];
  char just;
  int to_make_a_struct;
}
;

/*
  missing "struct"
*/
int 
foo
  (
  thing 
  T
  )
;
