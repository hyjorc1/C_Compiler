
int nope(int a)
{
  const 
  int 
  const   /* nope */
  a
  ;
}
