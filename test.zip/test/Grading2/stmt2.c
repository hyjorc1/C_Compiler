
int func(int x)
{
  for (x=0; x<10; x++) {
    x = 15;
    continue;
  }
}
