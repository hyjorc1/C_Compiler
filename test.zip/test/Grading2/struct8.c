
struct 
pair 
{
  x
  ;  /* Missing type names; error */
  y
  ;
}
;
