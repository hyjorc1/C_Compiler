
// bad syntax for a complicated expression

int error(int a)
{
  int b;

  b 
  = 
  1 
  + 
    a
    -
    1 
  + 
    a
    -
    2 
  + 
    a
    -
    3 
  + 
    a
    -
    4 
  + 
    a
    *
    a 
  + 
    a
    /
    a 
  + 
    a
    %
    5 
  + 
    a
  +
  + 
    7
  ;

  return b;
}
