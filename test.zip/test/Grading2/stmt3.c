
void func1(int x)
{
  x++;
  return;
}

int func2(int x)
{
  return x;
}

float func3(float x, float y)
{
  return x + y;
}
