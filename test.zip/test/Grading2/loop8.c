
int moreloops(int really)
{
  int x;

  x = 3;

  do 
    x++;    /* Allowed */
  while (x<5);  

  x = 4;
}
