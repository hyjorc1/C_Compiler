
int three(int a, int b, int c);

int bar(int a)
{
  int b;

  b = three(a, 2, 3, );

  return b;
}
