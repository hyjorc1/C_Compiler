
void proto3(
  int a,
  int b
);

int proto4(
  float u
  ,
  int v
  ,
  char w
  ,
  int x
  ,
  int y
  ,
  float z
);

