
int foo(int a)
{
  int x;

  x 
    = 
      a
      .
      w
      .
      x
      .
      .   /* oops */
      y
      .
      z
      ; 
}
