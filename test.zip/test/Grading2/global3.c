
int x, y[20], z;
float velocity[14];

int x(char a);

char buffer[1024], char filename[128];
float just, more, vars;

int y(float z);

char g, h, i;
int b;
