
int strange(int x)
{
  int y;

  int worse(int y)
  {
    /* Can't nest functions */
    int x;
  }

  int z;

}

