
void proto1();

void proto2(int a);

