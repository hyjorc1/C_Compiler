
/* Another illegal chain */

int error(int a)
{
  int b;

  b = 5;

  ++
  b 
  += 
  a
  ;

  return b++;
}
