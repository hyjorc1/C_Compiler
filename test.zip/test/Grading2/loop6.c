
int another(int x)
{
  int y;

  while ( x > 10 ) x--;

  while ( x < y )
    while ( y > 10 )
    {
      y--;
      x++;
    }
}
