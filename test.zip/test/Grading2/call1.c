
int zero();

int one(int a);

int bar(int a)
{
  int b;

  b = zero();

  b = one(4);

  return b;
}

