
int func(int x)
{
  while (x>10) {
    x--;
    break;    
  }
}
