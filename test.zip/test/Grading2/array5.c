
int error(int i)
{
  int A[10];
  int b;

  b = A
    [ 
    [
    i
    ] 
    ]
  ;

  return b;
}
