
/* Lexer should handle this easily */

int 
  a
  , 
  b
  , 
  c
  ;

