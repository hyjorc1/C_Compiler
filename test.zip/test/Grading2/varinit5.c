
int error(int a)
{
  int 
  b
  = 
  /* missing value */
  , 
  c
  ;
}
