
/*
  Since there's no typechecking,
  we don't need to define a struct
  to test for .
*/

int foo(int a)
{
  return a.member;
}
