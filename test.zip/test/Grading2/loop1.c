
int mything(int a)
{
  int sum;
  sum = 0;
  for (
    a=0; 
    a<10; 
    a++
  ) 
  {
    sum += a;
  }
  return a;
}
