
/* Syntax error with leading comma */

int 
  , 
  a
  , 
  b
  , 
  c
  ;
