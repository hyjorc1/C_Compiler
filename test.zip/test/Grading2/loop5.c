
int toxic_positivity()
{
  while (1) {
    putc(72);
    putc(101);
    putc(108);
    putc(108);
    putc(111);
    putc(33);
    putc(10);
  }
}

