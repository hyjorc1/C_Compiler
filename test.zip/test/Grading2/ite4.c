
// bad if syntax

int badone(int x)
{
  int y;

  if x
  {
    badone(1);
  }
}
