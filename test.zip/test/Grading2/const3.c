
const int A[50];

char const message[105];

int sum(int const A[], int N);


