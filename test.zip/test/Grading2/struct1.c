
struct point {
  int x, y;
};

int foo(int a)
{
  struct inner {
    char b, c, d;
  };
  char e;
}
