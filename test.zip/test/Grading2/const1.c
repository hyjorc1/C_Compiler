
const float pi;   /* Initialization would be better here */

float const e;


int thing(int x)
{
  const int a;
  int const b;
}
