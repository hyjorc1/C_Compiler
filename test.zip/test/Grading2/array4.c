
int bad(int A[])
{
  int b;
  b = A[ 
    0 
    + 
    A [
        1 
        + 
        A
          [
          2
          ]
      ]

    /* ]  oops */
  ; 
  return b;
}
