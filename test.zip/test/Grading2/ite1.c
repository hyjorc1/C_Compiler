
// basic if no braces

int main()
{
  int y;
  y = 5;
  if (y > 3) putc(10);
  y = 7;
}
