
const int sure(int a);

int also_good(int const b);

float log(const float base, float x);

