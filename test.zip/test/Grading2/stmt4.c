
int exprs(int a)
{
  int b;

  3;
  a;
  a+5;
  a*b;

  exprs(3);

  "Legal!";
}
