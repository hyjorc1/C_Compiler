
float var;
int A;

