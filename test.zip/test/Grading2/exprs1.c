
// unary -, !, ~

void bar(int a)
{
  int b;

  b = -a;

  a = !b;

  b = ~a;
}
