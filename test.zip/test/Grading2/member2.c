
int foo(int a[])
{
  int x;
  x = a[5].member;
}
