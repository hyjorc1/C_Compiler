
int foo(int a)
{
  int x, y;

  x = a[50].m1.m2.m3.m4[y.a[12].b.c[y.w].d].m6.whatever;
}
