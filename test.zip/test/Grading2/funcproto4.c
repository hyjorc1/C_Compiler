
void print(int z);

void empty();

void error(
  int a
  , 
  int b
  , 
);

