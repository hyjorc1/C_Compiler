
void proto1()
{
  int 
  a
  ;
}

void proto2(int a)
{
  int
  b
  ,
  c
  ,
  d
  ;
}

