
// bad if syntax

void bad(int x)
{
  if (x) 
  {
    x = 1;
  } 
  else 
  {
    x = 2;
  } 
  else 
  {
    x = 3;
  }
}
