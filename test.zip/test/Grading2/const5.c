
void 
error
(
const 
const   /* double secret const? */
x
)
;

