
int foo(int a)
{
  struct pair {
    int x;
    int y;
  }
  /* Missing ; */
  int
  z;
}
