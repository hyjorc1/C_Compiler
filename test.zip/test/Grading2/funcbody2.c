
void proto3(
  int a,
  int b
)
{
  printf ( "Hello, world!\n" ) ;
}

int proto4(
  float u
  ,
  int v
  ,
  char w
  ,
  int x
  ,
  int y
  ,
  float z
)
{
  int
  a
  ;
  float
  b
  ;
  char
  c
  ;

  printf(a, b);
}

