
void print(int z);

void empty();

void error(
  int
  a 
  , 
  b
  , 
  c
);

