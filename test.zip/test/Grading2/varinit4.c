
int error(int a=3)
{
  /* C++ allows that, but not C. */
  int b;
}
