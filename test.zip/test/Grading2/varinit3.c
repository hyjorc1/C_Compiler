
int foo(int a)
{
  int b=a;  

  int c, d=4, e, f=d+2, g=a*a+f;

}

int bar(int b)
{
  int c = foo(b);

}
