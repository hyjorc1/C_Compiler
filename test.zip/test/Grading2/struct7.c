
struct pair {
  int x, y;
};

/* NOT ALLOWED in C: */

pair center;

