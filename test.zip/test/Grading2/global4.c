
/* Syntax error with trailing commas */

int 
  a
  , 
  b
  , 
  c
  , 
  ;

