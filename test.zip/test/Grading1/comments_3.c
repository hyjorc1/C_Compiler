
// /* These are the trickier ones
;
/* Doesn't count: // */
still inside the comment even vi gets this wrong
*/
;
// /*
;
// */
