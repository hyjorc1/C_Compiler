float int
void
char
