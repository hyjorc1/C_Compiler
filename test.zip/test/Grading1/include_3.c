
start;

#include "inc1.h"

hello;

#include "inc2.h"

there;

#include "inc0.h"

done;

