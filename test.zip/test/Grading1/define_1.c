
#define N 6

"#define M 7"

4
5
N
M
8
