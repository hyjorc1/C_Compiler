
#define M_ _ 
#define MA a MB
#define MB b MC
#define MC c MD
#define MD d MC

M_

MA

