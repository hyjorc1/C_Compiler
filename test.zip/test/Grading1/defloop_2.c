
#define A a B
#define B b A

"also should fail:"

A

