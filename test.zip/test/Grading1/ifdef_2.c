
GOOD1

#ifndef DEBUG
  GOOD2
#endif

GOOD3

#define DEBUG

GOOD4

#ifndef DEBUG
  bad1 
#endif

GOOD5

#undef DEBUG

GOOD6

#ifndef DEBUG
  GOOD7
#endif

GOOD8

