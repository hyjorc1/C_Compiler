struct
const
