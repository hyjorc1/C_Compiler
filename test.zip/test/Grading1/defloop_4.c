
#define A a B
#define B b C
#define C c D
#define D d A
#undef B

A
B
C
D

"refreshing"

#define B b D

C
