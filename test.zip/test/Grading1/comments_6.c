a//bc
de/*fghijklm*/nop
/*//*/;
/**/;
/***/;
