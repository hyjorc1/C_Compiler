
/* */

/* C style comments */

; /* Multi line
     C style comment */

3/* This should split the token */4

/* * * * * * - + % , . all ignored even / that one */
