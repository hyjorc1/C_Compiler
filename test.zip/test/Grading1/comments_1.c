// Single line comment
;
// Nested // single // line // comments // no // big // deal //
;
