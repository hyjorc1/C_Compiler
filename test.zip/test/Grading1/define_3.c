
#define A 4
#define B A+1
#define C B+1

A;
B;
C;
