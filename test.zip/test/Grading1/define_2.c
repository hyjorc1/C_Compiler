
#define S "this is a macro"

YESS
YES
ES
S
"S"
