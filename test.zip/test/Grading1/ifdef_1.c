
GOOD1

#ifdef THING
  bad1
#endif

GOOD2

#define THING

GOOD3

#ifdef THING
  GOOD4
#endif

GOOD5

#undef THING

GOOD6

#ifdef THING
  bad2
#endif

GOOD7

