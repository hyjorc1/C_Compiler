
#define GNU GNU not Unix

"this should fail:"

GNU

