// "not a string"
// 12341515145
/* for while do */
