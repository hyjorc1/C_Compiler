i i23 x4 
A
a
printf
supercalifragilisticexpialidocious
