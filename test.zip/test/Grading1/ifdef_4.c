
GOOD1

#define YES

GOOD2

#ifdef YES
  GOOD3
#endif
  "Too many endifs, make sure there's a warning or error message"
#endif

ALIVE
