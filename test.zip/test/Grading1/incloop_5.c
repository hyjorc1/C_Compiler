
/*
    A                G
   / \              / \
  B   C            H   I
 / \ / \          / \ / \
D   E   F        C   J   A
                     |
                     G
*/

just;

#include "incloop5A.h"

wow;

#include "incloop5G.h"

done;

