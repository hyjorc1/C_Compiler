// Bizarre characters in comments are ok $
// â œ å ∂ é ó ç Ω 
// nothing to see here
