
"starting inc2";

#include "inc1.h"

"finishing inc2";

