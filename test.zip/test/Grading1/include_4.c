
line2;

#include "inc3.h"
#include "inc3.h"

line7;

#include "inc2.h"
#include "inc1.h"

line12;

