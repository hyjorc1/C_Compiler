
#endif

ALIVE

#ifdef THING

  bad1

#else

  GOOD

#else

  undefined here

#endif

BETTER

#ifndef BAIL

"unclosed ifndef, will there be a warning?"

