Cbegin

#include "incloop4d.h"

Cend
