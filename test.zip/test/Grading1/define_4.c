
#define C B+1
#define B A+1
#define A 4

A;
B;
C;
