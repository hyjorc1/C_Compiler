
warmup;

#include "inc1.h"

starting;

#include "incloop2a.h"

done;

