
/// JEXPR <clinit>

int nothing;

/** <clinit>
  .
  CODE
  .
**/

int main()
{
  return 3;
}
