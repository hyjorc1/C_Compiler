
/// JEXPR func

void func(int a, int b, int c, int d, int e, int f, int g)
{
  float x;

  g;  /** func 
        local6 
        CODE 
        iload * 6
      **/
  x;  /** func 
        local7 
        CODE 
        fload * 7
      **/
}
