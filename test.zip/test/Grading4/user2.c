
/// USER first
/// first types ([C)C
/// first stack 2
/// first locals 1
char first(char a[])
{
  return a[0];
}

/// USER complicated
/// complicated types ([II[FI)I
/// complicated stack 1
/// complicated locals 7
int complicated(int b[], int n, float c[], int m)
{
  int i,j,k;
  // nothing really
  return 0;
}
