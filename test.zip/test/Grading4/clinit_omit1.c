
/// JEXPR <clinit>

/** <clinit>
  .
  CODE
  .
**/

int main()
{
  return 3;
}
