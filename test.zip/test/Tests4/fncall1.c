
int sum(int x, int y) {
    return x + y;
}

int diff(int x, int y) {
    return x - y;
}

int main() {
  return sum(1, 2) + diff(2, 1); // 3 + 1 = 4
}
