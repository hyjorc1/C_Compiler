
void vf1() {  }
void vf2() { return; }

char cf1() { return 'a'; }
char cf2() { return (char) 98; }

int if1() { return 0; }
int if2() { return (int) 1.1; }
int if3() { return (int) 'a'; }

float ff1() { return 1.1; }
float ff2() { return (float) 1; }

int main() {
    return 0;
}
