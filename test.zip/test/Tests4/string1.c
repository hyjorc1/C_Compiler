int sum(char x[]) {
    return x[0] + x[1] + x[2]; // 97 + 98 + 99 = 294
}

int main() {
    return sum("abc"); // 294
}
