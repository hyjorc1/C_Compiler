
/// ASSEMBLY main

int main()
{
  return getchar();   /** main
                          invokestatic Method libc getchar [(][)]I
                      **/
}

