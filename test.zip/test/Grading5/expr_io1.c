
/// ASSEMBLY main

int main()
{
  putchar(72);  /** main
                    72,invokestatic Method libc putchar [(]I[)]I
                **/

  putchar(105); /** main
                    105,invokestatic Method libc putchar [(]I[)]I
                **/

  putchar(10);  /** main
                    10,invokestatic Method libc putchar [(]I[)]I
                **/
  return 0;
}
