
/// ASSEMBLY main

int main()
{
  putchar(putchar(getchar()));  /** main
      invokestatic Method libc getchar,invokestatic Method libc putchar,invokestatic Method libc putchar
  **/
  putchar(10);
  return 0;
}

