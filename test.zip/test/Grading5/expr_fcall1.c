
/// ASSEMBLY main

int main()
{
  return 17;    /** main
                    17,ireturn
                **/
}
