
/// ASSEMBLY main

int main()
{
  putchar(72);
  putchar(101);
  putchar(108);
  putchar(108);
  putchar(111);
  putchar(44);    /** main
                      44,invokestatic.*putchar
                  **/
  putchar(32);    /** main
                      32,invokestatic.*putchar
                  **/
  putchar(119);
  putchar(111);
  putchar(114);
  putchar(108);
  putchar(100);   /** main
                      100,invokestatic.*putchar
                  **/
  putchar(33);    /** main
                      33,invokestatic.*putchar
                  **/
  putchar(10);    /** main
                      10,invokestatic.*putchar
                  **/
  return 0;
}
